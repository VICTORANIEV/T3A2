package t3a5;

import java.util.Scanner;

public class T3A5 {

    
    public static void main(String[] args) {
        menu();
        
    }
    public static void menu(){
        Scanner scanner = new Scanner(System.in);
        Cuenta cuenta = new Cuenta();
        System.out.println("BIENBENIDO A BANCO 0101\n"
                + "1. Consultar saldo\n"
                + "2. Consultar estado de cuenta\n"
                + "3. Retirar efectivo\n"
                + "4. Otras opciones\n"
                + "5. Salir"
                + "\n\nElija una operacion");
        
        int operacion = scanner.nextInt();
        
        switch (operacion){
            
        case 1:
             cuenta.consultarSaldo();
             break;
         
        case 2:
            cuenta.estadoDeCuenta();
            break;
            
        case 3:
            cuenta.retirarEfectivo();
            break;
            
        case 4:
            System.out.println("1. Seguros\n"
                    + "2. creditos\n\n"
                    + "elija uno");
            int opcion = scanner.nextInt();
            
            switch(opcion){
                case 1:
                    cuenta.seguros();
                    break;
                    
                case 2:
                    cuenta.creditos();
                    break;
                
                default:
                    System.err.println("Elija una opcion valida");
                    break;
                 }
            
             case 5:
                    System.out.println("Gracias por su preferencia");
                    break;
            
        
        }
        
        
    }
}
